     
    
           		
	<div class="row-fluid">
		<div class="span12">
        <h1><strong>Rules and Regulation</strong>
		<span class="header-line"></span>
		</h1>
     </div>
	<!--/row-fluid -->
	
      
    <div class="row-fluid">
        	<div class="span6">
            <div class="square-background clearfix">
               	<div class="square square-back pull-left">
                   <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/01.png" alt="" class="">
          		</div>
				
                 <h4>A student will not be allowed to attend sessions if the admission formalities are not fulfilled</h4>
            
            </div>
                
            	<div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/02.png" alt="" class="">
          			</div>
					<br />
                     <h4>Attendence in the session and the test is compulsory</h4>
                     
                </div>
                
            	<div class="square-background clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/03.png" alt="" class="">
          			</div>
					<br />
                     <h4>Absenteeism must be informed prior to the session / test must be due to a valid reason.</h4>
                
                </div>
				
				 <div class="square-background square-colored clearfix">
               	<div class="square square-back pull-left">
                   <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/04.png" alt="" class="">
          		</div>
			
                 <h4>A student will be allowed to attend sessions after being absent if & only if he/she provides a sign letter from the parents stating the cause of absenteeism.</h4>
                
            </div>
                
            	<div class="square-background clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/05.png" alt="" class="">
          			</div>
                     <h4>A student will not be allowed to attend a sesion if he/she is late for session unless he/she carries a signed letter from either parent stating a valid reason.</h4>
                     
                </div>
                
            	<div class="square-background square-colored  clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/06.png" alt="" class="">
          			</div>
					<br />
                     <h4>A student must complete the work (written / studying) given to him / her on a daily basis.</h4>
                    
                </div>
      </div>
							
							
						
            <div class="span6">
            <div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/07.png" alt="" class="">
          </div>
                     <h4>In case the student is able to complete the work (written / studying) given to him / her, he/she must carry a signed letter from either parent stating a valid reason.</h4>
                    
              </div>
                
            <div class="square-background clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/08.png" alt="" class="">
          </div>
                     <h4>Permission for trips during vacations and absenteeism for trivial matters should not be requested for and will not be granted.</h4>
                     
              </div>
                
            <div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/09.png" alt="" class="">
                    </div>
                     <h4>Indiscipline of any kind will not be tolerated and will be dealt with very stictly.In case of expulsion of a student from NADS, fees will not be refunded.</h4>
                  
              </div>
				       
					   <div class="square-background clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/10.png" alt="" class="">
          </div>
                    <h4>Fees once paid will not be refunded under any circumstances,which may also include change of residence/school for any reason inconvinient timings etc.</h4>
                  
                </div>
                
            <div class="square-background square-colored clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/11.png" alt="" class="">
          </div>
		  <br />
                     <h4>Subjects once opted will not be changed under any circumstances</h4>
                     
              </div>
                
            <div class="square-background clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/12.png" alt="" class="">
                    </div>
                     <h4>NADS reserves theright to cancel and/or amend any course or fee details without prior notice.</h4>
                    
              </div>
					          
            </div>
		
		
            
</div> <!--/row-fluid-->
		
		
		
		
						
           
            
        </div> <!--/row-fluid-->
		
		
		
        
        <hr />

        <!--/row-fluid-->

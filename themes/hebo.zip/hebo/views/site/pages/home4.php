    <div class="slider-bootstrap"><!-- start slider -->
      		<img src="<?php echo Yii::app()->theme->baseUrl;?>/img/slider/flickr/s11.jpg" width="1000" height="430" />
    </div> <!-- /slider -->
   
    	<div class="row-fluid">        
        <div class="span3">
              
            <div class="colored_banner thumb-content">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson2.jpg" width="260" height="180" alt="Me" />
            <h3>
            Wordpress themes
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            </div>
           
        </div>
         
          <div class="span3">
           
            <div class="colored_banner thumb-content">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson4.jpg" width="260" height="180" />
            <h3>
            Blogger themes
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>

            </div>
          </div>
          
          <div class="span3">
              
            <div class="colored_banner thumb-content">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson5.jpg" width="260" height="180" />
            <h3>
            CSS3 themes
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            </div>
           
          </div>
          
          <div class="span3">
           
            <div class="colored_banner thumb-content">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson3.jpg" width="260" height="180" />
            <h3>
            HTML5 themes
            </h3>
            
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            </div>
          </div>
        
      </div>
      
      <hr>
      
       <div class="row-fluid">
            <div class="span9">
                <blockquote>
                  <h2>This is by far the best theme i have downloaded on webapplicationthemes.com. It was so easy to install and customize.</h2>
                  <small>Someone famous guy<cite title="Source Title"> - Harvard Business Review</cite></small>
                </blockquote>
            </div>
            
            <div class="span3" style="text-align:center;">
            
            <h3 class="text-error">What are you waiting for?</h3>
            
            <button class="btn btn-large btn-danger" type="button">DOWNLOAD IT NOW!</button>
            <p> <small>* terms and conditions apply</small></p>
            
            </div>
            
        </div>
       
       <h3 class="header">Our customers
      	<span class="header-line"></span>  
      </h3>
      <div class="row-fluid">
        <div class="span3 center">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/themeforest.png" alt="Themeforest" />
        </div>
        <div class="span3">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/codecanyon.png" alt="Codecanyon" />
        </div>
        <div class="span3">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/graphicriver.png" alt="Graphicriver" />
        </div>
        <div class="span3">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/photodune.png" alt="Photodune" />
        </div>
          
		</div><!--/row-fluid-->
    
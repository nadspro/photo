    	<!--<div class="row-fluid">        
        <div class="span4">
              
            <div class="colored_banner thumb-content-dark">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson2.jpg" width="260" height="180" alt="Me" />
            <h3>
            John Doe - <small>PHP Guru</small>
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            <div><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/facebook.png"  alt="Facebook" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/twitter.png"  alt="Twitter" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/linkedin.png"  alt="LinkedIn" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/google.png"  alt="Google+" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/email.png"  alt="RSS" /></div>
            
            </div>
           
        </div>-->
         
         <!-- <div class="span4">
           
            <div class="colored_banner thumb-content-dark">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson4.jpg" width="260" height="180" />
            <h3>
            Robert Lorem - <small>Support</small>
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            <div><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/facebook.png"  alt="Facebook" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/twitter.png"  alt="Twitter" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/linkedin.png"  alt="LinkedIn" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/google.png"  alt="Google+" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/email.png"  alt="RSS" /></div>

            </div>
          </div>
          
          <div class="span4">
              
            <div class="colored_banner thumb-content-dark">
            <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/simpson5.jpg" width="260" height="180" />
            <h3>
            David Ipsum - <small>Sales</small>
            </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            
            <div><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/facebook.png"  alt="Facebook" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/twitter.png"  alt="Twitter" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/linkedin.png"  alt="LinkedIn" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/google.png"  alt="Google+" /> <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/social/email.png"  alt="RSS" /></div>
            
            </div>
           
          </div>
          
      </div>
     </div>-->
	         <div class="page-header">
        <h1><font color="#CC6600">About us <small> everything you need to know</small></font></h1>
        </div>
     <div class="span12">
     	<h3 class="header"><font color="#CC6600" size="+2"><strong>Before you discover , you must explore. . .</strong></font>
        	<span class="header-line"></span> 
        </h3>
                  <large><font face="Georgia, Times New Roman, Times, serif"><strong>Some of our principal regrets in life are the opportunities we passed up and the chances we didn't take.</strong><cite title="Source Title"></cite></font></small>
		<blockquote>
					<small><font face="Arial, Helvetica, sans-serif" size="-1"><strong>NADS</strong> offers you a chance which you will never regret having taken, an opportunity to target academic success and to achieve it</font>.<cite title="Source Title"></cite></small>
				   
				 
				   <small ><font face="Arial, Helvetica, sans-serif" size="-1">And achieve it our student friends did, as our results have consistently shown, year after year after year!.</font><cite title="Source Title"></cite></small></font>
				   <ul class="list-icon">
          	<li><strong>They believed they had potential and that we were just the right people to help them discover it.</strong></li>
            <li><strong>They have kept faith in us, in our systems, in the principles we stand for.</strong></li>
				</ul>
				
				    <small ><font face="Arial, Helvetica, sans-serif" size="-1">We, on our part, stood by them, we learnt with them, for them and we are growing from them.</font><cite title="Source Title"></cite></small>
					
					 <small ><font face="Arial, Helvetica, sans-serif" size="-1">We are not big on words. We are big on keeping promises and the ones we have consistently kept are</font><cite title="Source Title"></cite></small>
					 <ul class="list-icon">
          	<li><strong>Focus on academic excellence</strong></li>
            <li><strong>Personalized attention</strong></li>
			<li><strong>Effective and evolving methods of study(computer aided learning, introduced in the current academic year</strong>)</li>
	        <li><strong>Customized personal counseling(which is an integral part of and unique to the learning process at NADS)</strong></li>
				</ul>
					  <small ><font face="Arial, Helvetica, sans-serif" size="-1">Besides emphasising on academic growth, we have over the years, broadened our focus on the overall development of the child thereby satisfying the needs of the child as well as those of the parent.	</font><cite title="Source Title"></cite></small>
					  </blockquote>
				 </div>
     
    <!-- <div class="span3">
    
      <h3 class="header">We are hiring
        	<span class="header-line"></span> 
      </h3>
      <div class="well">
      <p>We are always looking for talented people. If you think you have what it takes, please contact us.</p>
      <ul class="list-icon">
        <li>2 PHP programmers</li>
        <li>2 Graphic designers</li>
        <li>1 Sales executive</li>
        <li>1 Account executive</li>
        <li>3 .NET developers</li>
        <li>1 Systems administrator</li>
        <li>1 Public relations</li>
        <li>1 iOs developer</li>
      </ul>
      <p>
      <button class="btn btn-large btn-success" type="button">Join our team</button>
      </p>
     </div>
     </div>
    
  </div> 
  
  <hr />-->
  <div class="row-fluid">
           <div class="span12">
           		<h3 class="header"><strong>Achievements</strong>
                    <span class="header-line"></span> 
                </h3>
           		<ul class="nav nav-tabs">
                  <li class="active"><a href="#home" data-toggle="tab"><strong>Achievers</strong></a></li>
                  <li><a href="#profile" data-toggle="tab"><strong>Rankers And Hall Of Fame </strong></a></li>
                  <li><a href="#messages" data-toggle="tab"><strong>Subject Wise Toppers</strong></a></li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="home"><h3><strong>Achievers</strong></h3><!--<table class="table table-striped table-bordered table-hover">
				  				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/a1.png"/></center>
					<thead>
                        <tr>
                          <th>Photo</th>
                          <th>Name</th>
						  <th>School Name</th>
                          <th>Subject</th>
						  <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td><center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/Mehak Advani.png"/></center></td>
                          <td><strong>MEHAK ADVANI</strong></td>
                          <td><strong>J B Vacha</strong></td>
						  <td><strong>Science</strong></td>
						  <td><strong>95/100</strong></td>
                        </tr>
						<tr>
                          <td></td>
                          <td>RASHI JAIN</td>
                          <td>IES</td>
						  <td>Maths</td>
						  <td>135/150</td>
                        </tr>
						<tr>
                          <td></td>
                          <td>RIYA JAIN</td>
                          <td>DPYA</td>
						  <td>Maths</td>
						  <td>138/150</td>
                        </tr>
                        <tr>
                          <td></td>
                          <td>SHRUTI GADODIA</td>
                          <td>J B Vacha</td>
						  <td>Maths</td>
						  <td>141/150</td>
                        </tr>
						<tr>
                          <td></td>
                          <td>SIDDHARTH JAIN</td>
                          <td>Don Bosco</td>
						  <td>French</td>
						  <td>48/50</td>
                        </tr>
						<tr>
                          <td></td>
                          <td>SUSHIL DHADSE</td>
                          <td>SIWS</td>
						  <td>Marathi</td>
						  <td>82/100</td>
                        </tr>
                    </tbody>
				</table> -->
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/a1.png"/></center>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/a2.png"/></center>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/a3.png"/></center>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/a4.png"/></center>				
				</div>
                  <div class="tab-pane" id="profile"><h3><strong>Rankers And Hall Of Fame </strong></h3>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h6.png"/></center>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h5.png"/></center>
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h3.png"/></center>				
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h4.png"/></center>				
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h2.png"/></center>				
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/h1.png"/></center>


				
																  
				  </div>
                  <div class="tab-pane" id="messages"><h3><strong>Subject Wise Toppers</strong></h3>
				  <div class="span12">
           		<div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                     <strong> MARATHI, HINDI COMPOSITE, FRENCH </strong>
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse in">
                    <div class="accordion-inner">
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/mhf2.png"/></center>					
				<center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/mhf1.png"/></center>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                    <strong>SCIENCE, ENGLISH, SOCIAL SCIENCE </strong>
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse">
                    <div class="accordion-inner">
                     <center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/mhf4.png"/></center>					
                     <center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/mhf3.png"/></center>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                      <strong>AGGREGATE AND MATHS</strong>
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner">
                      <center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/am2.png"/></center>					
                     <center><img src="<?php echo Yii::app()->theme->baseUrl;?>/img/am1.png"/></center>
                    </div>
                  </div>
                </div>
              </div>
                
           </div>
		   
		   </div>
           </div>

   <!-- <div class="row-fluid">
        <ul class="thumbnails">
          <li class="span4">
            <div class="thumbnail">
            <h3>Our Mision</h3>
                               
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer commodo tristique odio, quis fringilla ligula aliquet ut. Maecenas sed justo varius velit imperdiet bibendum. Vivamus nec sapien massa, a imperdiet diam. Aliquam erat volutpat. Sed consectetur suscipit nunc et rutrum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
                 <h3>Our Philosophy</h3>
             
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer commodo tristique odio, quis fringilla ligula aliquet ut. Maecenas sed justo varius velit imperdiet bibendum. Vivamus nec sapien massa, a imperdiet diam. Aliquam erat volutpat. Sed consectetur suscipit nunc et rutrum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
                <h3>Our Values</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer commodo tristique odio, quis fringilla ligula aliquet ut. Maecenas sed justo varius velit imperdiet bibendum. Vivamus nec sapien massa, a imperdiet diam. Aliquam erat volutpat. Sed consectetur suscipit nunc et rutrum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </li>

        </ul>
    </div>
    
    <h3 class="header">Our services
        <span class="header-line"></span> 
    </h3>
      
    <div class="row-fluid">
        	<div class="span6">
            <div class="square-background clearfix">
               	<div class="square square-back pull-left">
                   <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-02.png" alt="" class="">
          		</div>
                 <h4>Theme documentation</h4>
                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
            </div>
                
            	<div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-05.png" alt="" class="">
          			</div>
                     <h4>Project management</h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
                </div>
                
            	<div class="square-background clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-20.png" alt="" class="">
          			</div>
                     <h4>Social marketing</h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
                </div>
            </div>
            <div class="span6">
            <div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-36.png" alt="" class="">
          </div>
                     <h4>Global consultancy</h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
                </div>
                
            <div class="square-background clearfix">
                    <div class="square square-back pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-37.png" alt="" class="">
          </div>
                     <h4>Mobile app development</h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
                </div>
                
            <div class="square-background square-colored clearfix">
                    <div class="square square-back  pull-left">
                        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/icons/smashing/60px/60px-17.png" alt="" class="">
          </div>
                     <h4>We also cook</h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante. </p>
                </div>
                
            </div>
            
        </div> 
        
        <hr />-->
  
  
 <!-- <h3 class="header">Our customers
    <span class="header-line"></span>  
  </h3>
  <div class="row-fluid">
    <div class="span3 center">
        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/themeforest.png" alt="Themeforest" />
    </div>
    <div class="span3">
        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/codecanyon.png" alt="Codecanyon" />
    </div>
    <div class="span3">
        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/graphicriver.png" alt="Graphicriver" />
    </div>
    <div class="span3">
        <img src="<?php echo Yii::app()->theme->baseUrl;?>/img/customers/photodune.png" alt="Photodune" />
    </div>
      
 </div><!--/row-fluid-->
 
   
    	<div class="page-header">
    		<h1><strong><font color="#CC6600" size="+3">Scheme OF Study</font></strong><small>Study Material, Test, Exam</small></h1>
        </div>
		  <div class="span11">
           		<div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                     <strong> STUDY MATERIAL </strong>
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse in">
                    <div class="accordion-inner">
				<ul class="list-icon">
          	<li><strong>Printed notes of ALL subjects of ALL standards where coaching is offered.
</strong></li>
            <li><strong>Printed notes of Maths.</strong></li>
			<li><strong>Exhaustive notes of Science, Social Studies, Hindi, Marathi<br/>
			<font color="#CC6600">1. <font size="+0.5">with emphasis on language of text </font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. <font size="+0.5">inclusive of all questions/answers available in all major publications.</font></font><br/>
</strong></li>
			<li><strong>Books on essay writing with model essays, letter writing, comprehension etc. for
all languages.</strong></li>
			<li><strong>Book on unseen passages and unseen poems for English.
</strong></li>
				</ul>
				<strong><font color="#FF0000" size="+1">NOTE :</font> We advise the students/parents not to spend money on buying various books available in the market as we provide all necessary material in all subjects</strong>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                    <strong>TEST </strong>
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse">
                    <div class="accordion-inner">
                    <ul class="list-icon">
          	<li><strong>Chapter-wise tests for all groups of subjects will be conducted every week.
</strong></li>
            <li><strong>Chapter-wise test in each and every subject will be exactly as per the Board
pattern.
</strong></li>
			<li><strong>At regular intervals, �combined chapter� tests will be held in every subject.
</strong></li>
			<li><strong>Solutions to the test with marking scheme will be made available to the student
along with the corrected paper.</strong></li>
			<li><strong>Book on unseen passages and unseen poems for English.
</strong></li>
<li><strong>Solutions to the test with marking scheme will be made available to the student
along with the corrected paper.</strong></li>
<li><strong>Corrected papers will be provided to the students within 10 days of writing the
test.</strong></li>
 <li><strong>Students have to get the <font color="#000000">signatures</font> of their<font color="#000000"> parents</font> on the <font color="#000000">very same day</font> and
<font color="#000000">submit</font> the <font color="#000000">signed papers</font> for verification of signatures in the <font color="#000000">very next session</font>,
after which the student files the papers, subject-wise.</strong></li>
				</ul>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                      <strong>PRELIMINARY EXAMINATION</strong>
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner">
                      <ul class="list-icon">
          	<li><strong>We shall conduct four preliminary examinations during the months of November, December, January & February.</strong></li>
            <li><strong>We shall conduct the 1st and the 2nd preliminary examinations in November & December.</strong></li>
			<li><strong>We shall conduct the 3rd and the 4th preliminary examinations between the
completion of the School Preliminary Examination and the commencement of the
SSC Board Examination.</strong></li>
				</ul>
                    </div>
                  </div>
                </div>
              </div>
                
           </div>
		   
		   </div>
           </div>
		
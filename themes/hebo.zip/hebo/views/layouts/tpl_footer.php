<section id="bottom" class="">
    <div class="container bottom"> 
    	<div class="row-fluid ">
            <div class="span3">
            	<h5><font color="#CC6600" size="+1"><strong>Care For Students..</strong></font></h5>
                <ul class="list-blog-roll">
                    <li>
                    	<font color="#CC6600" size="+1"><strong>1 .&nbsp;</strong></font><font color="#FFFFFF">Comfortable Classroom</font>
                    </li>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>2 .&nbsp;</strong></font><font color="#FFFFFF">Brightly lit as per scientific guidelines</font>
                    </li>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>3 .&nbsp;</strong></font><font color="#FFFFFF">Well illuminated wall to wall white magnetic boards</font>
                    </li>
					<li>
                    	<font color="#CC6600" size="+1"><strong>4 .&nbsp;</strong></font><font color="#FFFFFF">Ergonomically designed sitting arrangments	</font>
                    </li>
                </ul>
                
            </div><!-- /span3-->
            
            <div class="span3">
            	<br/>
				<br/>
            	<ul class="list-blog-roll">
				<li>
                    	<font color="#CC6600" size="+1"><strong>5 .&nbsp;</strong></font><font color="#FFFFFF">Sorry! You are being watched on closed</font>
                    </li>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>6 .&nbsp;</strong></font><font color="#FFFFFF">Aquaguard (with e-boiling feature)</font>
                    </li>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>7 .&nbsp;</strong></font><font color="#FFFFFF">First-aid available</font>
                    </li>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>8 .&nbsp;</strong></font><font color="#FFFFFF">Doctor on Call available</font>
                    </li>
                </ul>
            	
            </div><!-- /span3-->
            
            <div class="span3">
            	 <ul class="list-blog-roll">
				 <br/>
				 <br/>
                    <li>
                    	<font color="#CC6600" size="+1"><strong>9 .&nbsp;</strong></font><font color="#FFFFFF">Availability of fire extinguishers and emergency exit doors</font>	
                    </li>
					<li>
                    	<font color="#CC6600" size="+1"><strong>10 .&nbsp;</strong></font><font color="#FFFFFF">Annual Picnic</font>
                    </li>
					<li>
                    	<font color="#CC6600" size="+1"><strong>11 .&nbsp;</strong></font><font color="#FFFFFF">Felicitation of achievers in HSC/SCC Boards Exam</font>
                    </li>
                </ul>
            </div><!-- /span3--> 
            
            <div class="span3">
            	<h5><strong><font color="#CC6600" size="+1">Contact us</font></strong></h5>
                <p>
                    <font color="#FFFFFF">12 Shanti Niketan,</font><br/>
                    <font color="#FFFFFF">Plot # 322,</font><br/>
                    <font color="#FFFFFF">Dr Babasaheb Ambedkar Road,</font><br/>
                   <font color="#FFFFFF">King's Circle,</font><br/>
					<font color="#FFFFFF">Mumbai 400019.</font><br/>
					<font color="#FFFFFF">Phone&nbsp;-</font><font color="#CC6600">  +919833002008,<br/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+9122-24171984</font><br/>
					<font color="#FFFFFF">email&nbsp;-</font><font color="#CC6600">  nads7769@gmail.com</font><br/>
                </p>
            
                <h5><strong><font color="#CC6600" size="+1">Follow us</strong></font></h5>
                <ul>
                    <li><a href="https://www.facebook.com/pages/Naidus-Academy-of-Developmental-Studies/111068178912273">Facebook</a></li>
                    <!--<li><a href="#">Twitter</a></li>
                    <li><a href="#">Themeforest</a></li>
                 -->
                </ul>
            </div><!-- /span3-->
        </div><!-- /row-fluid -->
        </div><!-- /container-->
</section><!-- /bottom-->

<footer>
    <div class="footer">
        <div class="container">
        	Copyright &copy; 2013. Powered & Designed by <strong>Vidusys Info System Pvt. Ltd.</strong>
        </div>
	</div>
</footer>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-transition.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-alert.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-modal.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-tab.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-popover.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-button.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-collapse.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-carousel.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap-typeahead.js"></script>   
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>


  </body>
</html>